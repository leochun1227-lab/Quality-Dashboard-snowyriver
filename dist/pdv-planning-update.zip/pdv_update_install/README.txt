﻿Planning 安装方法

1. 找到 Planning 每晚 5 点实际运行的 Warranty 文件夹。
2. 将压缩包里的 pdv_update_install 文件夹解压到该 Warranty 文件夹内。
   Warranty 文件夹中应同时有：
   run_daily_5pm_mandt800_rejection_filter.bat
   pdv_update_install\install_on_planning.cmd
3. 双击 install_on_planning.cmd。看到 Installed and local checks passed 才算本地检查通过。

安装程序会保留原批处理备份，并更新其中 PDV 接入部分。
新脚本放在 Warranty 内的 pdv_dashboard 文件夹，不需要另一个 ozz-dashboard 文件夹。
使用 Warranty 现有的 Python、Firebase 凭据及分类文件；安装包不包含这些凭据或业务数据。
程序按自身位置找文件，不依赖用户名、盘符或任务的起始目录。
不会修改或启用 Windows 定时任务，不会在安装时抓数或写 Firebase。
晚间正常 Warranty 更新成功后，会自动接着发布独立 PDV 网页的数据。
检查网络及 Firebase 权限是否成功，需要查看首次实际更新日志：
logs\ctm_daily_5pm_YYYYMMDD.log
成功信息为 PASS: Firebase dashboard publication verified。

本版本新增 Claim Trend 月度 Claims / Issues 的 Total、Approved、Pending 汇总。
直接读取本机每日 Issue Position 步骤已经保存的完整扫描结果：
%LOCALAPPDATA%\WarrantyIssueAI\state\latest-position-result.json
因此必须在执行每日更新的同一 Windows 用户下运行；缺失或版本不符时保留上一版。
不增加 C4C 扫描或 AI 调用。安装后，下一次完整每日更新成功才会补齐网页 Issue 数据。
