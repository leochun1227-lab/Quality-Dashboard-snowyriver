@echo off
setlocal
if not exist "%~dp0..\run_daily_5pm_mandt800_rejection_filter.bat" (
  echo ERROR: Extract pdv_update_install INSIDE your existing Warranty folder.
  pause
  exit /b 1
)
set "PYTHON_CMD=python"
python --version >nul 2>&1
if errorlevel 1 (
  py -3 --version >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python was not found. Use the Python environment that runs Warranty.
    pause
    exit /b 1
  )
  set "PYTHON_CMD=py -3"
)
if "%PYTHON_CMD%"=="py -3" (
  py -3 "%~dp0install_daily_hook.py" --warranty-root "%~dp0.."
) else (
  "%PYTHON_CMD%" "%~dp0install_daily_hook.py" --warranty-root "%~dp0.."
)
if errorlevel 1 (
  echo ERROR: Installation failed. Review the message above.
  pause
  exit /b 1
)
call "%~dp0..\run_pdv_dashboard_update.bat" --check
if errorlevel 1 (
  echo ERROR: Files installed, but local checks failed. Fix the error before the next daily run.
  pause
  exit /b 1
)
echo PASS: Installed and local checks passed. No scheduled task was changed.
echo Firebase access is tested only when the normal daily update runs.
pause
exit /b 0
